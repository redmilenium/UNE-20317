#include <esp_now.h>
#include <esp_wifi.h>
#include <WiFi.h>
#include <WiFiMulti.h>
WiFiMulti wifiMulti;
#include <ArduinoOTA.h>

#include <PZEM004Tv30.h>
#define RXD2 16
#define TXD2 17
#define PZEM_SERIAL Serial2
PZEM004Tv30 pzem(PZEM_SERIAL, RXD2, TXD2);

unsigned long repeat=0;


// modificacion del PZEM-004T 
//https://www.youtube.com/watch?v=qRsjsenvlJA&ab_channel=TheHWcave


// PONER LA MAC DEL RECEPTOR REMOTO
// La puedes obtener ejecutando:
// Serial.println(WiFi.macAddress());

uint8_t broadcastAddress[] = {0xAC, 0x67, 0xB2, 0x34, 0x94, 0xEC};  // PONER LA MAC DEL RECEPTOR REMOTO

// Struct con los distintos datos a enviar
typedef struct struct_message {
  float voltage;
  float current;
  float power;
  float energy;
  float frequency;
  float pf;
  String medidor;
} struct_message;

// Create a struct_message called myData
struct_message myDataSen;

// callback when data is sent
void OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status) {
  Serial.print("\r\nLast Packet Send Status:\t");
  //Serial.println(status == ESP_NOW_SEND_SUCCESS ? "Delivery Success" : "Delivery Fail");
  if(status == ESP_NOW_SEND_SUCCESS )
  {
    Serial.println("Delivery Success");
    digitalWrite(LED_BUILTIN,HIGH);
    delay(100);
    digitalWrite(LED_BUILTIN,LOW);
  }else
  { 
    Serial.println("Delivery Fail");
   }
 
}
void connectWifi()
{

  // Conectando Wi-Fi
  // PON TU SSID  y PASSWORD
  wifiMulti.addAP(" ", " ");//SSID  y PASSWORD
 

  Serial.println("Pillando Wifi...");


IPAddress ip(192,168,1,19);     // utiliza una ip que no este dentro del rango del DHCP de tu router y que no este ya utilizada...
IPAddress gateway(192,168,1,1);   
IPAddress subnet(255,255,255,0);   
IPAddress dns1(80,58,61,250);   
IPAddress dns2(80,58,61,254); 

WiFi.config(ip, gateway, subnet, dns1, dns2);

  Serial.println(WiFi.macAddress());  // POR SI QUIERES SABER LA MAC DE TU ESP32

   while(wifiMulti.run() != WL_CONNECTED)
   {
      Serial.print(".");
      
      delay (1000);
   }

}

//**********************************************************************************
void InitOTA()
{
  // Port defaults to ESP32
  ArduinoOTA.setPort(3232);
  ArduinoOTA.setHostname("kwh");
  ArduinoOTA.setPassword("abracadabra"); 

  ArduinoOTA.onStart([]() {
    String type;
    if (ArduinoOTA.getCommand() == U_FLASH) {
      type = "sketch";
    } else { // U_SPIFFS
      type = "filesystem";
    }

    // NOTE: if updating SPIFFS this would be the place to unmount SPIFFS using SPIFFS.end()
    //Serial.println("Start updating " + type);
  });

  ArduinoOTA.onEnd([]() {
    //Serial.println("\nEnd");
  });

  ArduinoOTA.onProgress([](unsigned int progress, unsigned int total) {
    //Serial.printf("Progress: %u%%\r", (progress / (total / 100)));
  });

  ArduinoOTA.onError([](ota_error_t error) {
    //Serial.printf("Error[%u]: ", error);
    if (error == OTA_AUTH_ERROR) {
      //Serial.println("Auth Failed");
    } else if (error == OTA_BEGIN_ERROR) {
      //Serial.println("Begin Failed");
    } else if (error == OTA_CONNECT_ERROR) {
      //Serial.println("Connect Failed");
    } else if (error == OTA_RECEIVE_ERROR) {
      //Serial.println("Receive Failed");
    } else if (error == OTA_END_ERROR) {
      //Serial.println("End Failed");
    }
  });

  ArduinoOTA.begin();
  //Serial.println("");
  Serial.println("OTA iniciado");
}
//*****************************************************************************************************************


void setup() {
  // Init Serial Monitor
pinMode(LED_BUILTIN,OUTPUT);
digitalWrite(LED_BUILTIN,LOW);

Serial.begin(115200);
WiFi.mode(WIFI_STA);

connectWifi();

esp_wifi_set_ps(WIFI_PS_NONE);

delay(1000);

 


  // Init ESP-NOW
  if (esp_now_init() != ESP_OK) {
    Serial.println("Error initializing ESP-NOW");
    return;
  }


  
  
  // Register peer
  esp_now_peer_info_t peerInfo;
  memcpy(peerInfo.peer_addr, broadcastAddress, 6);
  peerInfo.channel = 0; 
  peerInfo.encrypt = false;
  

  // Add peer        
  if (esp_now_add_peer(&peerInfo) != ESP_OK){
    Serial.println("Failed to add peer");
    return;
  }

// Once ESPNow is successfully Init, we will register for Send CB to
  // get the status of Trasnmitted packet
  esp_now_register_send_cb(OnDataSent);


  InitOTA();
  repeat=millis();
}
 
void loop() {
 ArduinoOTA.handle();

// leo los valores que ha conseguido el PZEM004 cada segundo y los envio al equipo remoto
  if(millis()-repeat>1000UL)
{
  repeat=millis();
    // Set values to send
  myDataSen.voltage= pzem.voltage();
  myDataSen.current= pzem.current();
  myDataSen.power = pzem.power();
  myDataSen.energy = pzem.energy();
  myDataSen.frequency = pzem.frequency();
  myDataSen.pf = pzem.pf();
  myDataSen.medidor=(pzem.readAddress(), HEX);
 
   // Send message via ESP-NOW
  esp_err_t result = esp_now_send(broadcastAddress, (uint8_t *) &myDataSen, sizeof(myDataSen));
   
  if (result == ESP_OK) {
    Serial.println("Sent with success");
  }
  else {
    Serial.println("Error sending the data");
  }
}

}


